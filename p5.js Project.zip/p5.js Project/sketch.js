// JavaScript source code
function setup() {
    createCanvas(500, 500);
}

function draw() {
    background(165, 207, 250);

    //face
    noStroke()
    fill(247, 221, 212);
    ellipse(200, 200,300, 380);

    //hair
    noStroke()
    fill(32, 19, 19);
    rect(50, 10, 50, 400);
    rect(65, 10, 270, 50);
    rect(300, 10, 50, 400);

    //eyes
    ellipse(250, 150, 30, 35);
    ellipse(150, 150, 30, 35);


    //Nose
    //strokeWeight(2)
    stroke('black')
    strokeWeight(1)
    fill(255, 237, 156);
    triangle(165, 250, 208, 200, 230, 250);

    //Mouth
    noStroke()
    fill(255, 102, 102);
    arc(200, 300, 80, 50, 0, PI);

    //eyebrow
    stroke('black')
    strokeWeight(3)
    line(235, 110, 270, 110);
    line(130, 110, 165, 110);

    //eye points
    stroke('white');
    strokeWeight(3)
    point(250, 150);
    point(150, 150);

    //Title
    textSize(32);
    text('Sarah Shapes', 100, 40);

    //signature
    text('Sarah Brown', 300, 470)


    
    


}